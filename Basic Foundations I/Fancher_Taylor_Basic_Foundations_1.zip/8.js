var Y = "";
var counter = 0;

for ( var i = 0; i < arr.length; i++) {
    if (arr[i] > Y) {
        counter++;
    }
}
console.log(counter);
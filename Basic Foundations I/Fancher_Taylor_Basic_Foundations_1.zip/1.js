for (var i = 1; i <= 255; i++) {
    console.log(i);
}
var testArr = [6,3,5,1,2,4]

var sum = 0;
for (var i = 0; i < testArr.length; i++){
    console.log(testArr[i]);
    sum = sum + console.log(testArr[i]);
    console.log(sum);
}